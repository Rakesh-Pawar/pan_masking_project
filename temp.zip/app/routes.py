from fastapi import APIRouter, UploadFile, File
from services.image_processing import process_pan_image
import shutil

router = APIRouter()

@router.post("/upload/")
async def upload_pan_card(file: UploadFile = File(...)):
    file_path = f"temp/{file.filename}"

    # Save the uploaded image temporarily
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    # Process the image
    masked_image_path = process_pan_image(file_path)

    return {"message": "PAN card processed successfully!", "masked_image": masked_image_path}
