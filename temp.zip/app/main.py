from fastapi import FastAPI
from app.routes import router

app = FastAPI(title="PAN Card Masking API using DeepSeek-Vision")

# Default homepage
@app.get("/")
async def home():
    return {"message": "Welcome to PAN Card Masking API!"}

app.include_router(router)
