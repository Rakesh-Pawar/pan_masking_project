import cv2
import numpy as np
import os
import requests
import json
from app.config import UPLOAD_FOLDER

# DeepSeek-Vision API Endpoint
DEEPSEEK_API_URL = "https://api.deepseek.com/vision"
DEEPSEEK_API_KEY = "sk-011d8c6d61de45ada377d2c2762440da"  # Replace with actual API Key

def correct_orientation(image_path):
    """Corrects the orientation of the image if tilted."""
    image = cv2.imread(image_path)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    edges = cv2.Canny(gray, 50, 150, apertureSize=3)
    lines = cv2.HoughLinesP(edges, 1, np.pi/180, threshold=100, minLineLength=100, maxLineGap=10)

    if lines is not None:
        angles = [np.arctan2(y2 - y1, x2 - x1) for x1, y1, x2, y2 in lines[:, 0]]
        median_angle = np.median(angles) * (180 / np.pi)
        rotation_matrix = cv2.getRotationMatrix2D((gray.shape[1]//2, gray.shape[0]//2), median_angle, 1)
        rotated_image = cv2.warpAffine(image, rotation_matrix, (gray.shape[1], gray.shape[0]))
        cv2.imwrite(image_path, rotated_image)

    return image_path

def detect_pan_number(image_path):
    """Uses DeepSeek-Vision API to detect PAN number."""
    headers = {
        "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
        "Content-Type": "application/json"
    }

    with open(image_path, "rb") as image_file:
        files = {"file": image_file}
        response = requests.post(DEEPSEEK_API_URL, headers=headers, files=files)

    if response.status_code == 200:
        text_data = response.json()
        detected_text = text_data.get("text", "")

        # Extract PAN number using regex
        import re
        match = re.search(r"[A-Z]{5}[0-9]{4}[A-Z]{1}", detected_text)
        if match:
            return match.group(0)
    
    return None

def mask_pan_number(image_path, pan_number):
    """Masks the detected PAN number."""
    if not pan_number:
        return None

    image = cv2.imread(image_path)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Detect text positions
    h, w, _ = image.shape
    d = detect_pan_number(image_path)

    # Here, we assume the API returns coordinates (not all APIs do)
    for item in d:
        if item["text"] == pan_number:
            x, y, width, height = item["coordinates"]
            cv2.rectangle(image, (x, y), (x + width, y + height), (0, 0, 0), -1)

    masked_image_path = os.path.join(UPLOAD_FOLDER, os.path.basename(image_path))
    cv2.imwrite(masked_image_path, image)

    return masked_image_path

def process_pan_image(image_path):
    """Complete processing: align, detect, and mask PAN number."""
    corrected_path = correct_orientation(image_path)
    pan_number = detect_pan_number(corrected_path)

    if not pan_number:
        return {"error": "PAN number not found!"}

    masked_image_path = mask_pan_number(corrected_path, pan_number)

    return masked_image_path
